#ifndef IO_HELPER_H
#define IO_HELPER_H

int read_int();
  //@ requires true;
  //@ ensures true;
  
#endif