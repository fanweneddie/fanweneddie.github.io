vfide -bindir ../bin/stdlib nsl/nsl.c
