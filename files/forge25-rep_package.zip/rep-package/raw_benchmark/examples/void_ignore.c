void foo(int x)
//@ requires true;
//@ ensures true;
{
	(void) x;
}
