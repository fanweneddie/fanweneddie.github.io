#ifndef TEST_H
#define TEST_H

void test();
  //@ requires true;
  //@ ensures true;

#endif
